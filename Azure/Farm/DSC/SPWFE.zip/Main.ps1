﻿configuration Main 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [psobject]$Data
    ) 
    
    Import-DscResource -ModuleName xTimeZone, PSDesiredStateConfiguration
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)

    Node localhost
    {
        xTimeZone SetToEST {
            TimeZone = "Eastern Standard Time"
        }

        LocalConfigurationManager 
        {
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }
   }
} 